/**
 * 
 * @param creep 
 */
export function runRemoteHarvester(creep: Creep): void {
    
}