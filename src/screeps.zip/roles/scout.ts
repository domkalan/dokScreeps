export function runScout(creep: Creep): void {
    
}