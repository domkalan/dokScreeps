declare global {
    // Definition for the global console object
    const console: {
        log(...data: any[]): void;
        warn(...data: any[]): void;
        error(...data: any[]): void;
    };

    // Definition for the require function
    function require(id: string): any;

    interface CreepMemory {
        role: string;
        room: string;
        taskId?: string;
        goingFor?: string; // the id of the energy source the creep is currently going for, if any
    }

    interface ConstructionPlanItem {
        x: number;
        y: number;
        structureType: BuildableStructureConstant;
        priority: number;

        /**
         * Minimum controller level before the planner attempts this item.
         */
        minRcl: number;
    }

    interface ConstructionPlannerMemory {
        enabled: boolean;

        /**
         * Maximum active construction sites allowed in this room.
         */
        maxSites: number;

        /**
         * Maximum new sites created during a single planner run.
         */
        placementsPerRun: number;

        /**
         * Number of ticks between planner runs.
         */
        interval: number;

        /**
         * Last tick the planner attempted to place sites.
         */
        lastRun: number;

        /**
         * Persistent blueprint for the room.
         */
        plan: ConstructionPlanItem[];
    }

    interface RoomMemory {
        lastScan: number;
        energySources: string[];
        remoteEnergySources?: { room: string; id: string }[];

        controllerLevel?: number;

        tasks: { [taskId: string]: RoomTask };

        spawnQueue: {
            role: string;
            priority: number;
        }[];

        constructionPlanner?: ConstructionPlannerMemory;
    }

    interface RoomTask {
        id: string;
        assigned: string;
        type: string;
        targetId: string;
        priority: number;
    }

    interface Memory {
        creeps: { [creepName: string]: CreepMemory };
        rooms: { [roomName: string]: RoomMemory };
        counter: { [key: string]: number };
    }
}

export {};